/**
 * ==========================================================================
 * PREDICTA-AI DASHBOARD - FRONTEND BUSINESS LOGIC
 * ==========================================================================
 */

// Global Dashboard State
const state = {
    backendUrl: 'http://127.0.0.1:5050/api',
    currentAsset: 'nifty',
    currentModel: 'linear',
    lookbackDays: 365,
    forecastDays: 7,
    
    // Chart instances
    priceChart: null,
    rsiChart: null,
    macdChart: null,
    activeTab: 'price',
    
    // SMA visibility flags
    showSma20: true,
    showSma50: true,
    
    // Cached response data
    historyData: [],
    predictionData: {}
};

// SVG Icon Helpers
const ICONS = {
    bullish: `<svg class="icon text-success" viewBox="0 0 24 24" width="16" height="16" stroke="currentColor" stroke-width="2.5" fill="none"><polyline points="23 6 13.5 15.5 8.5 10.5 1 18"></polyline><polyline points="17 6 23 6 23 12"></polyline></svg>`,
    bearish: `<svg class="icon text-danger" viewBox="0 0 24 24" width="16" height="16" stroke="currentColor" stroke-width="2.5" fill="none"><polyline points="23 18 13.5 8.5 8.5 13.5 1 6"></polyline><polyline points="17 18 23 18 23 12"></polyline></svg>`,
    neutral: `<svg class="icon text-warning" viewBox="0 0 24 24" width="16" height="16" stroke="currentColor" stroke-width="2.5" fill="none"><line x1="5" y1="12" x2="19" y2="12"></line></svg>`
};

// Document Ready Initialization
document.addEventListener('DOMContentLoaded', () => {
    initDateTime();
    initEventListeners();
    fetchDashboardData();
    pollSidebarPrices();
});

// Set current date in header
function initDateTime() {
    const dateEl = document.getElementById('currentDate');
    const options = { weekday: 'long', year: 'numeric', month: 'short', day: 'numeric' };
    dateEl.textContent = new Date().toLocaleDateString('en-US', options);
}

// Bind HTML elements and triggers
function initEventListeners() {
    // 1. Sidebar Asset selection
    const assetCards = document.querySelectorAll('.asset-card');
    assetCards.forEach(card => {
        card.addEventListener('click', () => {
            assetCards.forEach(c => c.classList.remove('active'));
            card.classList.add('active');
            state.currentAsset = card.dataset.asset;
            fetchDashboardData();
        });
    });

    // 2. Sliders
    const lookbackSlider = document.getElementById('lookbackSlider');
    const lookbackVal = document.getElementById('lookbackVal');
    lookbackSlider.addEventListener('input', (e) => {
        state.lookbackDays = parseInt(e.target.value);
        lookbackVal.textContent = `${state.lookbackDays} Days`;
    });

    const forecastSlider = document.getElementById('forecastSlider');
    const forecastVal = document.getElementById('forecastVal');
    forecastSlider.addEventListener('input', (e) => {
        state.forecastDays = parseInt(e.target.value);
        forecastVal.textContent = `${state.forecastDays} Days`;
    });

    // 3. Dropdown Model type
    const modelSelect = document.getElementById('modelSelect');
    modelSelect.addEventListener('change', (e) => {
        state.currentModel = e.target.value;
    });

    // 4. Retrain Button
    const btnTrain = document.getElementById('btnTrain');
    btnTrain.addEventListener('click', () => {
        fetchDashboardData();
    });

    // 5. Chart Tabs
    const tabs = document.querySelectorAll('.chart-tab');
    tabs.forEach(tab => {
        tab.addEventListener('click', (e) => {
            tabs.forEach(t => t.classList.remove('active'));
            tab.classList.add('active');
            
            const chartType = tab.dataset.chart;
            state.activeTab = chartType;
            
            // Toggle Canvas elements
            document.getElementById('mainChart').classList.add('hidden-chart');
            document.getElementById('rsiChart').classList.add('hidden-chart');
            document.getElementById('macdChart').classList.add('hidden-chart');
            
            const legendEl = document.querySelector('.chart-legend');
            
            if (chartType === 'price') {
                document.getElementById('mainChart').classList.remove('hidden-chart');
                legendEl.style.opacity = '1';
                legendEl.style.pointerEvents = 'auto';
                if (state.priceChart) {
                    state.priceChart.resize();
                    state.priceChart.update();
                }
            } else if (chartType === 'rsi') {
                document.getElementById('rsiChart').classList.remove('hidden-chart');
                legendEl.style.opacity = '0';
                legendEl.style.pointerEvents = 'none';
                if (state.rsiChart) {
                    state.rsiChart.resize();
                    state.rsiChart.update();
                }
            } else if (chartType === 'macd') {
                document.getElementById('macdChart').classList.remove('hidden-chart');
                legendEl.style.opacity = '0';
                legendEl.style.pointerEvents = 'none';
                if (state.macdChart) {
                    state.macdChart.resize();
                    state.macdChart.update();
                }
            }
        });
    });

    // 6. Legend SMA toggling
    const toggleSma20 = document.getElementById('toggleSma20');
    toggleSma20.addEventListener('click', () => {
        state.showSma20 = !state.showSma20;
        toggleSma20.classList.toggle('muted', !state.showSma20);
        if (state.priceChart) {
            state.priceChart.setDatasetVisibility(2, state.showSma20); // Dataset index 2 is SMA 20
            state.priceChart.update();
        }
    });

    const toggleSma50 = document.getElementById('toggleSma50');
    toggleSma50.addEventListener('click', () => {
        state.showSma50 = !state.showSma50;
        toggleSma50.classList.toggle('muted', !state.showSma50);
        if (state.priceChart) {
            state.priceChart.setDatasetVisibility(3, state.showSma50); // Dataset index 3 is SMA 50
            state.priceChart.update();
        }
    });

    // 7. Help Drawer Toggle
    const btnHelp = document.getElementById('btnHelp');
    const btnCloseGuide = document.getElementById('btnCloseGuide');
    const guideDrawer = document.getElementById('guideDrawer');
    
    if (btnHelp && btnCloseGuide && guideDrawer) {
        btnHelp.addEventListener('click', () => {
            guideDrawer.classList.add('active');
        });
        
        btnCloseGuide.addEventListener('click', () => {
            guideDrawer.classList.remove('active');
        });
    }
}

// Fetch main prediction payloads from server
async function fetchDashboardData() {
    const loader = document.getElementById('loaderOverlay');
    loader.classList.add('active');
    
    const statusDot = document.getElementById('statusDot');
    const statusText = document.getElementById('statusText');
    
    try {
        const fetchPredict = fetch(`${state.backendUrl}/predict?asset=${state.currentAsset}&model=${state.currentModel}&lookback=${state.lookbackDays}&forecast=${state.forecastDays}`);
        const fetchNews = fetch(`${state.backendUrl}/news?asset=${state.currentAsset}`);
        
        const [resPredict, resNews] = await Promise.all([fetchPredict, fetchNews]);
        
        if (!resPredict.ok || !resNews.ok) {
            throw new Error("HTTP error connecting to backend.");
        }
        
        const dataPredict = await resPredict.json();
        const dataNews = await resNews.json();
        
        statusDot.className = 'status-dot online';
        statusText.textContent = 'Connected to Backend';
        
        state.historyData = dataPredict.history;
        state.predictionData = dataPredict.prediction;
        
        // Update UI
        updateSummaryPanel(dataPredict.summary);
        updateNextDayPanel(dataPredict.next_day_forecast, dataPredict.summary.unit);
        updateMetricsPanel(dataPredict.prediction, dataPredict.summary.unit);
        updateNewsPanel(dataNews);
        
        // Render Charts
        renderPriceForecastChart(dataPredict);
        renderRsiChart(dataPredict.history);
        renderMacdChart(dataPredict.history);
        
    } catch (err) {
        console.error("API error:", err);
        statusDot.className = 'status-dot offline';
        statusText.textContent = 'Backend Offline / Error';
        showToast("Error communicating with Python backend server.");
    } finally {
        loader.classList.remove('active');
    }
}

// Background task to populate sidebar values dynamically
async function pollSidebarPrices() {
    const assets = ['nifty', 'sensex', 'gold', 'silver', 'usd_inr'];
    for (const key of assets) {
        try {
            const res = await fetch(`${state.backendUrl}/predict?asset=${key}&model=linear&lookback=90&forecast=1`);
            if (res.ok) {
                const data = await res.json();
                const summary = data.summary;
                
                // Set sidebar values
                const priceEl = document.getElementById(`sidebar-price-${key}`);
                const changeEl = document.getElementById(`sidebar-change-${key}`);
                
                if (priceEl && changeEl) {
                    const prefix = key === 'gold' || key === 'silver' ? '$' : '₹';
                    const precision = key === 'usd_inr' || key === 'silver' ? 2 : 1;
                    priceEl.textContent = `${prefix}${summary.current_price.toLocaleString(undefined, {minimumFractionDigits: precision, maximumFractionDigits: precision})}`;
                    
                    const pct = summary.pct_change;
                    changeEl.textContent = `${pct >= 0 ? '+' : ''}${pct.toFixed(2)}%`;
                    changeEl.className = `asset-change ${pct >= 0 ? 'up' : 'down'}`;
                }
            }
        } catch (e) {
            console.warn(`Sidebar polling failed for ${key}:`, e);
        }
    }
}

// Update primary statistics fields
function updateSummaryPanel(summary) {
    document.getElementById('currentAssetName').textContent = `${summary.name} Dashboard`;
    
    // Set data source text
    document.getElementById('dataSourceBadge').textContent = `Source: ${summary.fetched_from_web ? 'Yahoo Finance (Real-time)' : 'Local Brownian Simulation'}`;
    
    const priceEl = document.getElementById('statPrice');
    const changeEl = document.getElementById('statPriceChange');
    const highEl = document.getElementById('statHigh');
    const lowEl = document.getElementById('statLow');
    const signalEl = document.getElementById('statSignal');
    const signalsListEl = document.getElementById('statSignalsList');
    const trendIconEl = document.getElementById('trendIcon');
    
    const sign = summary.unit === 'INR' ? '₹' : '$';
    const precision = state.currentAsset === 'usd_inr' || state.currentAsset === 'silver' ? 2 : 1;
    
    priceEl.textContent = `${sign}${summary.current_price.toLocaleString(undefined, {minimumFractionDigits: precision, maximumFractionDigits: precision})}`;
    
    // Price change styling
    const chg = summary.price_change;
    const pct = summary.pct_change;
    changeEl.className = `stat-subtext ${pct >= 0 ? 'up' : 'down'}`;
    changeEl.innerHTML = `<span class="arrow">${pct >= 0 ? '▲' : '▼'}</span> <span class="val">${sign}${Math.abs(chg).toFixed(precision)} (${pct >= 0 ? '+' : ''}${pct.toFixed(2)}%)</span>`;
    
    // High / Low
    highEl.textContent = `${sign}${summary.high_24h.toLocaleString(undefined, {minimumFractionDigits: precision, maximumFractionDigits: precision})}`;
    lowEl.textContent = `${sign}${summary.low_24h.toLocaleString(undefined, {minimumFractionDigits: precision, maximumFractionDigits: precision})}`;
    
    // Technical Signal
    signalEl.textContent = summary.overall_signal;
    signalEl.className = `stat-value text-${summary.signal_color}`;
    
    // Trend icon styling
    if (summary.signal_color === 'success') {
        trendIconEl.style.color = 'var(--success)';
        trendIconEl.style.background = 'var(--success-glow)';
        trendIconEl.innerHTML = `<svg viewBox="0 0 24 24" width="20" height="20" stroke="currentColor" stroke-width="2.5" fill="none"><polyline points="23 6 13.5 15.5 8.5 10.5 1 18"></polyline><polyline points="17 6 23 6 23 12"></polyline></svg>`;
    } else if (summary.signal_color === 'danger') {
        trendIconEl.style.color = 'var(--danger)';
        trendIconEl.style.background = 'var(--danger-glow)';
        trendIconEl.innerHTML = `<svg viewBox="0 0 24 24" width="20" height="20" stroke="currentColor" stroke-width="2.5" fill="none"><polyline points="23 18 13.5 8.5 8.5 13.5 1 6"></polyline><polyline points="17 18 23 18 23 12"></polyline></svg>`;
    } else {
        trendIconEl.style.color = 'var(--warning)';
        trendIconEl.style.background = 'var(--warning-glow)';
        trendIconEl.innerHTML = `<svg viewBox="0 0 24 24" width="20" height="20" stroke="currentColor" stroke-width="2.5" fill="none"><line x1="5" y1="12" x2="19" y2="12"></line></svg>`;
    }
    
    signalsListEl.textContent = summary.signals_list.join(" | ");
}

// Update Tomorrow's Forecast card
function updateNextDayPanel(nextDay, unit) {
    const priceEl = document.getElementById('nextDayPrice');
    const changeEl = document.getElementById('nextDayChange');
    const iconEl = document.getElementById('forecastIcon');
    
    if (!priceEl || !changeEl || !iconEl) return;
    
    const sign = unit === 'INR' ? '₹' : '$';
    const precision = state.currentAsset === 'usd_inr' || state.currentAsset === 'silver' ? 2 : 1;
    
    priceEl.textContent = `${sign}${nextDay.predicted_price.toLocaleString(undefined, {minimumFractionDigits: precision, maximumFractionDigits: precision})}`;
    
    const pct = nextDay.expected_pct_change;
    const chg = nextDay.expected_change;
    const isUp = nextDay.direction === 'UP';
    
    changeEl.className = `stat-subtext ${isUp ? 'up' : 'down'}`;
    changeEl.innerHTML = `<span class="arrow">${isUp ? '▲' : '▼'}</span> <span class="val">${sign}${Math.abs(chg).toFixed(precision)} (${isUp ? '+' : ''}${pct.toFixed(2)}%)</span>`;
    
    // Update next-day forecast icon matching direction
    if (isUp) {
        iconEl.style.color = 'var(--success)';
        iconEl.style.background = 'var(--success-glow)';
        iconEl.innerHTML = `<svg viewBox="0 0 24 24" width="20" height="20" stroke="currentColor" stroke-width="2.5" fill="none"><polyline points="23 6 13.5 15.5 8.5 10.5 1 18"></polyline><polyline points="17 6 23 6 23 12"></polyline></svg>`;
    } else {
        iconEl.style.color = 'var(--danger)';
        iconEl.style.background = 'var(--danger-glow)';
        iconEl.innerHTML = `<svg viewBox="0 0 24 24" width="20" height="20" stroke="currentColor" stroke-width="2.5" fill="none"><polyline points="23 18 13.5 8.5 8.5 13.5 1 6"></polyline><polyline points="17 18 23 18 23 12"></polyline></svg>`;
    }
}

// Update model validation stats
function updateMetricsPanel(prediction, unit) {
    const metrics = prediction.metrics;
    
    const precision = state.currentAsset === 'usd_inr' || state.currentAsset === 'silver' ? 3 : 1;
    
    // MAE & RMSE
    document.getElementById('metricMAE').textContent = metrics.mae.toFixed(precision);
    document.getElementById('metricUnitMAE').textContent = unit;
    
    document.getElementById('metricRMSE').textContent = metrics.rmse.toFixed(precision);
    document.getElementById('metricUnitRMSE').textContent = unit;
    
    // R-Squared Score
    const r2 = metrics.r2;
    const r2Pct = Math.max(0, Math.min(100, r2 * 100)); // Cap between 0 and 100 for visual bar
    document.getElementById('metricR2').textContent = r2.toFixed(3);
    document.getElementById('r2ProgressBar').style.width = `${r2Pct}%`;
    
    // Accuracy
    const acc = metrics.accuracy;
    document.getElementById('metricAccuracy').textContent = `${acc.toFixed(1)}%`;
    document.getElementById('accProgressBar').style.width = `${acc}%`;
}

// Update simulated News widgets
function updateNewsPanel(newsData) {
    const listEl = document.getElementById('newsList');
    listEl.innerHTML = '';
    
    // News items
    newsData.news.forEach(item => {
        const card = document.createElement('div');
        card.className = 'news-item';
        
        const sentimentClass = item.sentiment.toLowerCase();
        
        card.innerHTML = `
            <div class="news-header">
                <span class="news-source">${item.source}</span>
                <span class="news-time">${item.time}</span>
            </div>
            <div class="news-title">${item.title}</div>
            <div class="news-footer">
                <span class="sentiment-badge ${sentimentClass}">${item.sentiment}</span>
                <span class="news-impact">Est. Price Impact: <strong class="${sentimentClass === 'bullish' ? 'text-success' : sentimentClass === 'bearish' ? 'text-danger' : 'text-secondary'}">${item.impact}</strong></span>
            </div>
        `;
        listEl.appendChild(card);
    });
    
    // News sentiment aggregate score
    const score = newsData.sentiment_score;
    const label = newsData.sentiment_label;
    
    document.getElementById('statSentimentScore').textContent = `${score}%`;
    document.getElementById('statSentimentLabel').textContent = label;
    
    const fillEl = document.getElementById('sentimentBar');
    fillEl.style.width = `${score}%`;
}

// Render Price Forecast Chart.js component
function renderPriceForecastChart(data) {
    const ctx = document.getElementById('mainChart').getContext('2d');
    
    const history = data.history;
    const forecast = data.prediction;
    
    const histDates = history.map(h => h.Date);
    const predDates = forecast.dates;
    
    // Combine X-axis dates
    const labels = [...histDates, ...predDates];
    
    const histPrices = history.map(h => h.Close);
    const predPrices = forecast.predictions;
    
    // Align datasets
    // Actual price dataset ends right where prediction begins
    const actualData = [...histPrices, ...Array(predPrices.length).fill(null)];
    
    // Predicted price dataset starts with the last actual price to connect the lines smoothly
    const forecastData = [
        ...Array(histPrices.length - 1).fill(null),
        histPrices[histPrices.length - 1],
        ...predPrices
    ];
    
    // SMA lines
    const sma20Data = [...history.map(h => h.SMA_20), ...Array(predPrices.length).fill(null)];
    const sma50Data = [...history.map(h => h.SMA_50), ...Array(predPrices.length).fill(null)];
    
    // Volume data and colors (green for up-days, red for down-days)
    const histVolume = history.map(h => h.Volume);
    const volumeData = [...histVolume, ...Array(predPrices.length).fill(null)];
    const volumeColors = history.map(h => h.Close >= h.Open ? 'rgba(0, 230, 118, 0.08)' : 'rgba(255, 23, 68, 0.08)');
    const maxVolume = Math.max(...histVolume) || 1000000;

    // Destroy previous instance
    if (state.priceChart) {
        state.priceChart.destroy();
    }
    
    // Creating Line Gradients
    const gradientActual = ctx.createLinearGradient(0, 0, 0, 300);
    gradientActual.addColorStop(0, 'rgba(0, 136, 255, 0.15)');
    gradientActual.addColorStop(1, 'rgba(0, 136, 255, 0)');
    
    const gradientForecast = ctx.createLinearGradient(0, 0, 0, 300);
    gradientForecast.addColorStop(0, 'rgba(0, 229, 255, 0.15)');
    gradientForecast.addColorStop(1, 'rgba(0, 229, 255, 0)');
    
    state.priceChart = new Chart(ctx, {
        type: 'line',
        data: {
            labels: labels,
            datasets: [
                {
                    label: 'Actual Price',
                    data: actualData,
                    borderColor: '#0088ff',
                    borderWidth: 2,
                    pointRadius: 0,
                    pointHitRadius: 10,
                    fill: true,
                    backgroundColor: gradientActual,
                    tension: 0.1,
                    yAxisID: 'y',
                    order: 2
                },
                {
                    label: 'Forecasted Price',
                    data: forecastData,
                    borderColor: '#00e5ff',
                    borderWidth: 2,
                    borderDash: [4, 4],
                    pointRadius: 0,
                    pointHitRadius: 10,
                    fill: true,
                    backgroundColor: gradientForecast,
                    tension: 0.1,
                    yAxisID: 'y',
                    order: 3
                },
                {
                    label: 'SMA 20',
                    data: sma20Data,
                    borderColor: '#00e676',
                    borderWidth: 1,
                    pointRadius: 0,
                    fill: false,
                    hidden: !state.showSma20,
                    tension: 0.08,
                    yAxisID: 'y',
                    order: 4
                },
                {
                    label: 'SMA 50',
                    data: sma50Data,
                    borderColor: '#ffb300',
                    borderWidth: 1,
                    pointRadius: 0,
                    fill: false,
                    hidden: !state.showSma50,
                    tension: 0.08,
                    yAxisID: 'y',
                    order: 5
                },
                {
                    label: 'Volume',
                    data: volumeData,
                    type: 'bar',
                    backgroundColor: volumeColors,
                    borderColor: 'transparent',
                    yAxisID: 'yVolume',
                    barPercentage: 0.75,
                    categoryPercentage: 0.85,
                    order: 10 // Render behind the price lines
                }
            ]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { display: false } // Custom legend is in HTML
            },
            scales: {
                x: {
                    grid: { color: 'rgba(255, 255, 255, 0.02)' },
                    ticks: {
                        color: '#64748b',
                        font: { size: 10 },
                        maxTicksLimit: 12
                    }
                },
                y: {
                    type: 'linear',
                    display: true,
                    position: 'left',
                    grid: { color: 'rgba(255, 255, 255, 0.02)' },
                    ticks: {
                        color: '#64748b',
                        font: { size: 10 }
                    }
                },
                yVolume: {
                    type: 'linear',
                    display: false, // Hide y-axis scale for volume to keep visual clean
                    position: 'right',
                    grid: { drawOnChartArea: false },
                    min: 0,
                    max: maxVolume * 4 // Compresses volume bars to occupy only bottom 25% of chart
                }
            },
            interaction: {
                intersect: false,
                mode: 'index'
            }
        },
        plugins: [
            {
                id: 'crosshair',
                afterDraw: (chart) => {
                    if (chart.tooltip?._active?.length) {
                        const activePoint = chart.tooltip._active[0];
                        const { ctx } = chart;
                        const { x, y } = activePoint.element;
                        const topY = chart.chartArea.top;
                        const bottomY = chart.chartArea.bottom;
                        const leftX = chart.chartArea.left;
                        const rightX = chart.chartArea.right;
                        
                        ctx.save();
                        ctx.beginPath();
                        ctx.setLineDash([4, 4]);
                        ctx.strokeStyle = 'rgba(255, 255, 255, 0.15)';
                        ctx.lineWidth = 1;
                        
                        // Draw Vertical Crosshair Line
                        ctx.moveTo(x, topY);
                        ctx.lineTo(x, bottomY);
                        
                        // Draw Horizontal Crosshair Line
                        ctx.moveTo(leftX, y);
                        ctx.lineTo(rightX, y);
                        
                        ctx.stroke();
                        ctx.restore();
                    }
                }
            }
        ]
    });
}

// Render RSI Chart
function renderRsiChart(history) {
    const ctx = document.getElementById('rsiChart').getContext('2d');
    const labels = history.map(h => h.Date);
    const rsiValues = history.map(h => h.RSI);
    
    if (state.rsiChart) {
        state.rsiChart.destroy();
    }
    
    state.rsiChart = new Chart(ctx, {
        type: 'line',
        data: {
            labels: labels,
            datasets: [{
                label: 'RSI',
                data: rsiValues,
                borderColor: '#7f56d9',
                borderWidth: 2,
                pointRadius: 0,
                tension: 0.15,
                fill: false
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: { legend: { display: false } },
            scales: {
                x: {
                    grid: { color: 'rgba(255, 255, 255, 0.03)' },
                    ticks: { color: '#64748b', font: { size: 10 }, maxTicksLimit: 12 }
                },
                y: {
                    min: 10,
                    max: 90,
                    grid: { color: 'rgba(255, 255, 255, 0.03)' },
                    ticks: { color: '#64748b', font: { size: 10 } }
                }
            },
            // Draw RSI support lines at 30 and 70 manually in chart
            // For custom UI, adding background fill areas via canvas layers
            plugins: {
                beforeDraw: (chart) => {
                    const {ctx, chartArea: {top, bottom, left, right}} = chart;
                    ctx.save();
                    // Overbought zone boundary (70)
                    ctx.strokeStyle = 'rgba(244, 63, 94, 0.35)';
                    ctx.lineWidth = 1;
                    ctx.setLineDash([4, 4]);
                    
                    const yScale = chart.scales.y;
                    const y70 = yScale.getPixelForValue(70);
                    const y30 = yScale.getPixelForValue(30);
                    
                    // Draw 70 line
                    ctx.beginPath();
                    ctx.moveTo(left, y70);
                    ctx.lineTo(right, y70);
                    ctx.stroke();
                    
                    // Draw 30 line
                    ctx.strokeStyle = 'rgba(16, 185, 129, 0.35)';
                    ctx.beginPath();
                    ctx.moveTo(left, y30);
                    ctx.lineTo(right, y30);
                    ctx.stroke();
                    
                    // Fill mid-range shading
                    ctx.fillStyle = 'rgba(255, 255, 255, 0.015)';
                    ctx.fillRect(left, y70, right - left, y30 - y70);
                    
                    ctx.restore();
                }
            }
        }
    });
}

// Render MACD Chart
function renderMacdChart(history) {
    const ctx = document.getElementById('macdChart').getContext('2d');
    const labels = history.map(h => h.Date);
    
    const macd = history.map(h => h.MACD);
    const macdSignal = history.map(h => h.MACD_Signal);
    const macdHist = history.map(h => h.MACD_Hist);
    
    if (state.macdChart) {
        state.macdChart.destroy();
    }
    
    // For histogram bars, we map background colors dynamically (green if positive, red if negative)
    const histColors = macdHist.map(val => val >= 0 ? 'rgba(16, 185, 129, 0.4)' : 'rgba(244, 63, 94, 0.4)');
    const histBorderColors = macdHist.map(val => val >= 0 ? '#10b981' : '#f43f5e');
    
    state.macdChart = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: labels,
            datasets: [
                {
                    label: 'MACD Histogram',
                    data: macdHist,
                    backgroundColor: histColors,
                    borderColor: histBorderColors,
                    borderWidth: 1.2,
                    borderRadius: 2,
                    order: 3
                },
                {
                    label: 'MACD',
                    data: macd,
                    borderColor: '#00f2fe',
                    borderWidth: 2,
                    pointRadius: 0,
                    type: 'line',
                    fill: false,
                    tension: 0.15,
                    order: 1
                },
                {
                    label: 'Signal Line',
                    data: macdSignal,
                    borderColor: '#f59e0b',
                    borderWidth: 1.5,
                    pointRadius: 0,
                    type: 'line',
                    fill: false,
                    tension: 0.15,
                    order: 2
                }
            ]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: { legend: { display: false } },
            scales: {
                x: {
                    grid: { color: 'rgba(255, 255, 255, 0.03)' },
                    ticks: { color: '#64748b', font: { size: 10 }, maxTicksLimit: 12 }
                },
                y: {
                    grid: { color: 'rgba(255, 255, 255, 0.03)' },
                    ticks: { color: '#64748b', font: { size: 10 } }
                }
            }
        }
    });
}

// Custom Toast notification helper
function showToast(message) {
    const toast = document.createElement('div');
    toast.className = 'toast-alert';
    toast.textContent = message;
    
    // Inject dynamic CSS rules for Toast inline
    Object.assign(toast.style, {
        position: 'fixed',
        bottom: '24px',
        right: '24px',
        background: 'rgba(244, 63, 94, 0.9)',
        border: '1px solid rgba(255, 255, 255, 0.2)',
        color: '#fff',
        padding: '12px 24px',
        borderRadius: '10px',
        fontSize: '13px',
        fontWeight: '600',
        boxShadow: '0 4px 15px rgba(0, 0, 0, 0.3)',
        zIndex: '1000',
        backdropFilter: 'blur(8px)',
        opacity: '0',
        transform: 'translateY(10px)',
        transition: 'all 0.3s cubic-bezier(0.18, 0.89, 0.32, 1.28)'
    });
    
    document.body.appendChild(toast);
    
    // Trigger animation
    setTimeout(() => {
        toast.style.opacity = '1';
        toast.style.transform = 'translateY(0)';
    }, 50);
    
    // Auto destroy
    setTimeout(() => {
        toast.style.opacity = '0';
        toast.style.transform = 'translateY(10px)';
        setTimeout(() => toast.remove(), 300);
    }, 4000);
}
