import sys
import os

# Set paths
sys.path.append(os.path.join(os.path.dirname(__file__), "backend"))

try:
    from data_fetcher import fetch_data, get_asset_summary
    from model import train_and_predict
    
    print("[TEST 1] Testing Data Fetcher (with mock fallback)...")
    # Fetch data (will use mock since standard sandbox has no network)
    df, fetched = fetch_data("nifty")
    print(f" - Data columns: {list(df.columns)}")
    print(f" - Data length: {len(df)}")
    print(f" - Fetched from web? {fetched}")
    
    print("\n[TEST 2] Testing Asset Summary...")
    summary = get_asset_summary(df, "nifty")
    print(f" - Current Price: {summary['current_price']}")
    print(f" - Overall Signal: {summary['overall_signal']}")
    
    print("\n[TEST 3] Testing ML Training and Prediction...")
    forecast_days = 7
    lookback_days = 180
    res = train_and_predict(df, model_type='linear', forecast_days=forecast_days, lookback_days=lookback_days)
    
    print(f" - Metrics MAE: {res['metrics']['mae']:.4f}")
    print(f" - Metrics RMSE: {res['metrics']['rmse']:.4f}")
    print(f" - Metrics R2: {res['metrics']['r2']:.4f}")
    print(f" - Directional Accuracy: {res['metrics']['accuracy']:.2f}%")
    print(f" - Forecast predictions length: {len(res['predictions'])}")
    print(f" - First forecast price: {res['predictions'][0]:.4f}")
    
    print("\n[SUCCESS] All backend modules verified successfully!")
    
except Exception as e:
    import traceback
    traceback.print_exc()
    print(f"\n[FAILURE] Backend test failed: {e}")
    sys.exit(1)
