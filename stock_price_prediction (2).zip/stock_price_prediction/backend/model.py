import numpy as np
import pandas as pd
from sklearn.linear_model import LinearRegression
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score
from datetime import datetime, timedelta

def build_features(df):
    """
    Creates feature columns for time-series forecasting.
    To predict Close(t), features must only contain information up to t-1.
    """
    df_feat = df.copy()
    
    # Target: Close price at time t
    df_feat['Target'] = df_feat['Close']
    
    # Features (lagged values)
    df_feat['Lag_1'] = df_feat['Close'].shift(1)
    df_feat['Lag_2'] = df_feat['Close'].shift(2)
    df_feat['Lag_3'] = df_feat['Close'].shift(3)
    df_feat['Lag_5'] = df_feat['Close'].shift(5)
    
    # Technical indicator features (lagged)
    df_feat['RSI_Lag1'] = df_feat['RSI'].shift(1)
    df_feat['MACD_Lag1'] = df_feat['MACD'].shift(1)
    df_feat['MACD_Sig_Lag1'] = df_feat['MACD_Signal'].shift(1)
    df_feat['SMA_20_Lag1'] = df_feat['SMA_20'].shift(1)
    df_feat['SMA_50_Lag1'] = df_feat['SMA_50'].shift(1)
    
    # Difference features (spreads)
    df_feat['SMA_Diff_Lag1'] = df_feat['Lag_1'] - df_feat['SMA_20_Lag1']
    
    # Drop rows with NaNs caused by lagging
    df_feat = df_feat.dropna()
    
    feature_cols = [
        'Lag_1', 'Lag_2', 'Lag_3', 'Lag_5', 
        'RSI_Lag1', 'MACD_Lag1', 'MACD_Sig_Lag1', 
        'SMA_20_Lag1', 'SMA_50_Lag1', 'SMA_Diff_Lag1'
    ]
    
    return df_feat, feature_cols

def train_and_predict(df, model_type='linear', forecast_days=7, lookback_days=180):
    """
    Trains a model on the historical data, computes test metrics,
    and returns future recursive forecasts.
    """
    # 1. Filter data based on lookback window
    if len(df) > lookback_days:
        df_filtered = df.iloc[-lookback_days:].copy()
    else:
        df_filtered = df.copy()
        
    # 2. Build features
    df_feat, feature_cols = build_features(df_filtered)
    
    if len(df_feat) < 30:
        raise ValueError("Insufficient data points for training with current lookback window.")
        
    X = df_feat[feature_cols].values
    y = df_feat['Target'].values
    
    # 3. Time Series Train/Test Split (Temporal)
    # 80% training, 20% testing (no random shuffling to preserve temporal structure)
    split_idx = int(len(df_feat) * 0.8)
    X_train, X_test = X[:split_idx], X[split_idx:]
    y_train, y_test = y[:split_idx], y[split_idx:]
    
    # 4. Initialize model
    if model_type == 'random_forest':
        model = RandomForestRegressor(n_estimators=100, max_depth=6, random_state=42)
    else:
        model = LinearRegression()
        
    # Train model on training set to evaluate metrics
    model.fit(X_train, y_train)
    y_pred = model.predict(X_test)
    
    # Calculate metrics
    mae = mean_absolute_error(y_test, y_pred)
    rmse = np.sqrt(mean_squared_error(y_test, y_pred))
    r2 = r2_score(y_test, y_pred)
    
    # Calculate Directional Accuracy: did the model predict the correct up/down move?
    actual_diff = np.diff(np.concatenate([[y_train[-1]], y_test]))
    pred_diff = np.diff(np.concatenate([[y_train[-1]], y_pred]))
    directional_accuracy = np.mean((actual_diff * pred_diff) > 0) * 100
    
    # 5. Retrain model on all available lookback data for future predictions
    if model_type == 'random_forest':
        final_model = RandomForestRegressor(n_estimators=100, max_depth=6, random_state=42)
    else:
        final_model = LinearRegression()
    final_model.fit(X, y)
    
    # 6. Recursive multi-step forecasting
    # We predict day by day, updating the lags recursively
    last_row = df_feat.iloc[-1]
    
    # We maintain a history of close prices to calculate recursive features
    history_close = list(df_feat['Close'].values)
    
    # Maintain list of recent indicator values to feed recursive estimation
    history_rsi = list(df_feat['RSI'].values)
    history_macd = list(df_feat['MACD'].values)
    history_macdsig = list(df_feat['MACD_Signal'].values)
    history_sma20 = list(df_feat['SMA_20'].values)
    history_sma50 = list(df_feat['SMA_50'].values)
    
    predictions = []
    future_dates = []
    
    # Set starting date for future prediction
    last_date = datetime.strptime(df_feat.iloc[-1]['Date'], "%Y-%m-%d")
    current_date = last_date
    
    for _ in range(forecast_days):
        # Move date to next business day (skipping weekends)
        current_date += timedelta(days=1)
        while current_date.weekday() >= 5: # 5 = Saturday, 6 = Sunday
            current_date += timedelta(days=1)
        future_dates.append(current_date.strftime("%Y-%m-%d"))
        
        # Build features for current prediction step (t)
        # Using values from history at indices -1 (t-1), -2 (t-2), etc.
        lag1 = history_close[-1]
        lag2 = history_close[-2]
        lag3 = history_close[-3]
        lag5 = history_close[-5]
        
        rsi_lag1 = history_rsi[-1]
        macd_lag1 = history_macd[-1]
        macdsig_lag1 = history_macdsig[-1]
        sma20_lag1 = history_sma20[-1]
        sma50_lag1 = history_sma50[-1]
        sma_diff_lag1 = lag1 - sma20_lag1
        
        feat_vector = np.array([[
            lag1, lag2, lag3, lag5,
            rsi_lag1, macd_lag1, macdsig_lag1,
            sma20_lag1, sma50_lag1, sma_diff_lag1
        ]])
        
        # Predict close price
        pred_close = float(final_model.predict(feat_vector)[0])
        
        # Make sure price doesn't go negative
        pred_close = max(pred_close, 0.01)
        predictions.append(pred_close)
        
        # Append predicted price to history
        history_close.append(pred_close)
        
        # Update technical indicators for subsequent steps (recursive approximations)
        # SMA_20: mean of last 20 close prices
        new_sma20 = np.mean(history_close[-20:])
        history_sma20.append(new_sma20)
        
        # SMA_50: mean of last 50 close prices
        new_sma50 = np.mean(history_close[-50:])
        history_sma50.append(new_sma50)
        
        # RSI approximation (use simple momentum decay for simplicity in recursive steps)
        rsi_change = (pred_close - lag1) / lag1
        new_rsi = rsi_lag1 * 0.95 + (50 + rsi_change * 500) * 0.05
        new_rsi = min(max(new_rsi, 10), 90) # Clip boundaries
        history_rsi.append(new_rsi)
        
        # MACD decay approximation
        new_macd = macd_lag1 * 0.95
        new_macdsig = macdsig_lag1 * 0.95
        history_macd.append(new_macd)
        history_macdsig.append(new_macdsig)
        
    return {
        "dates": future_dates,
        "predictions": predictions,
        "metrics": {
            "mae": float(mae),
            "rmse": float(rmse),
            "r2": float(r2),
            "accuracy": float(directional_accuracy)
        }
    }

if __name__ == "__main__":
    from data_fetcher import fetch_data
    df, _ = fetch_data("gold")
    res = train_and_predict(df, model_type='linear', forecast_days=7)
    print("Metrics:", res["metrics"])
    print("Forecast dates:", res["dates"])
    print("Forecast prices:", res["predictions"])
