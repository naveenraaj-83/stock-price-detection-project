import subprocess
import sys
import os
import time
import webbrowser
import signal

def main():
    print("=========================================================")
    print("      PREDICTA-AI STOCK PRICE PREDICTION DASHBOARD       ")
    print("=========================================================")
    print("Starting services...")

    # Get absolute path of the script directory
    script_dir = os.path.dirname(os.path.abspath(__file__))
    os.chdir(script_dir)

    # Determine Python executable (prioritize local virtualenv if it exists)
    if os.name == 'nt':  # Windows
        venv_python = os.path.join(script_dir, "venv", "Scripts", "python.exe")
    else:  # Unix/Mac
        venv_python = os.path.join(script_dir, "venv", "bin", "python")

    if os.path.exists(venv_python):
        python_exe = venv_python
        print(f"Using virtual environment Python: {python_exe}")
    else:
        python_exe = sys.executable
        if not python_exe:
            python_exe = "python"
        print(f"Using system Python: {python_exe}")

    backend_path = os.path.join("backend", "server.py")
    frontend_dir = "frontend"

    # Start Flask Backend Server
    print("--> Booting Python Flask API Server on port 5050...")
    backend_process = subprocess.Popen(
        [python_exe, backend_path],
        cwd=script_dir,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
        bufsize=1
    )

    # Start Simple HTTP Server for Frontend
    print("--> Booting static HTML Frontend Server on port 8000...")
    frontend_process = subprocess.Popen(
        [python_exe, "-m", "http.server", "8000"],
        cwd=os.path.join(script_dir, frontend_dir),
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL
    )

    # Wait a moment and check if processes are running
    time.sleep(2.5)

    if backend_process.poll() is not None:
        print("\n[ERROR] Failed to start backend server. Error logs:")
        output, _ = backend_process.communicate()
        print(output)
        # Terminate frontend
        frontend_process.terminate()
        sys.exit(1)

    print("\n[SUCCESS] Servers are running successfully!")
    print(" - Backend API:  http://127.0.0.1:5050")
    print(" - Frontend Dashboard: http://localhost:8000")
    print("\nOpening dashboard in your web browser...")
    
    try:
        webbrowser.open("http://localhost:8000")
    except Exception as e:
        print(f"Could not open browser automatically: {e}")
        print("Please manually open http://localhost:8000 in your web browser.")

    print("\nPress Ctrl+C to terminate both servers and exit.")

    # Read backend logs in a non-blocking/blocking loop to keep main thread alive
    try:
        while True:
            line = backend_process.stdout.readline()
            if not line:
                break
            # Print backend logs in console for transparency
            print(f"[Backend] {line.strip()}")
    except KeyboardInterrupt:
        print("\n\nShutting down servers...")
    finally:
        # Terminate processes
        try:
            print("Stopping backend server...")
            backend_process.terminate()
            backend_process.wait(timeout=3)
        except Exception:
            backend_process.kill()

        try:
            print("Stopping frontend server...")
            frontend_process.terminate()
            frontend_process.wait(timeout=3)
        except Exception:
            frontend_process.kill()

        print("Shutdown complete. Goodbye!")

if __name__ == "__main__":
    main()
