import pandas as pd
import numpy as np
import yfinance as yf
from datetime import datetime, timedelta

# Asset config mapping key to yfinance ticker and metadata
ASSETS = {
    "gold": {
        "ticker": "GC=F",
        "name": "Gold Futures",
        "base_price": 2300.0,
        "volatility": 0.012,  # daily volatility
        "drift": 0.0003,       # daily drift
        "unit": "USD/oz"
    },
    "silver": {
        "ticker": "SI=F",
        "name": "Silver Futures",
        "base_price": 29.5,
        "volatility": 0.018,
        "drift": 0.0002,
        "unit": "USD/oz"
    },
    "nifty": {
        "ticker": "^NSEI",
        "name": "Nifty 50",
        "base_price": 23400.0,
        "volatility": 0.01,
        "drift": 0.0005,
        "unit": "INR"
    },
    "sensex": {
        "ticker": "^BSESN",
        "name": "Sensex",
        "base_price": 76800.0,
        "volatility": 0.0095,
        "drift": 0.00045,
        "unit": "INR"
    },
    "usd_inr": {
        "ticker": "INR=X",
        "name": "USD/INR",
        "base_price": 83.5,
        "volatility": 0.002,
        "drift": 0.00005,
        "unit": "INR"
    }
}

def generate_mock_data(asset_key, start_date, end_date):
    """
    Generates realistic asset price data using Geometric Brownian Motion (GBM)
    and adds realistic volume and technical features.
    """
    asset_info = ASSETS.get(asset_key)
    if not asset_info:
        raise ValueError(f"Unknown asset key: {asset_key}")
        
    np.random.seed(42 + hash(asset_key) % 100) # Stable seed per asset
    
    # Calculate number of days
    start = datetime.strptime(start_date, "%Y-%m-%d")
    end = datetime.strptime(end_date, "%Y-%m-%d")
    delta_days = (end - start).days
    
    # Create business days date range
    dates = pd.bdate_range(start=start, end=end)
    n = len(dates)
    
    # GBM parameters
    s0 = asset_info["base_price"]
    mu = asset_info["drift"]
    sigma = asset_info["volatility"]
    
    # Simulate prices
    # S(t) = S(t-1) * exp((mu - sigma^2/2) + sigma * Z)
    returns = np.random.normal(loc=mu - (sigma**2)/2, scale=sigma, size=n)
    price_multipliers = np.exp(returns)
    prices = np.zeros(n)
    prices[0] = s0
    
    for i in range(1, n):
        prices[i] = prices[i-1] * price_multipliers[i]
        
    # Create Open, High, Low, Close based on simulated close price
    df = pd.DataFrame(index=dates)
    df['Close'] = prices
    
    # Add intraday spread
    noise = np.random.uniform(0.001, 0.005, size=n)
    df['Open'] = df['Close'] * (1 + np.random.normal(0, 0.002, size=n))
    df['High'] = df[['Open', 'Close']].max(axis=1) * (1 + noise)
    df['Low'] = df[['Open', 'Close']].min(axis=1) * (1 - noise)
    
    # Volume: simulated with higher volume on large price changes
    base_vol = 1000000 if "nifty" in asset_key or "sensex" in asset_key else 10000
    df['Volume'] = np.abs(np.random.normal(base_vol, base_vol*0.3, size=n))
    
    # Reset index to make Date a column
    df = df.reset_index().rename(columns={'index': 'Date'})
    df['Date'] = df['Date'].dt.strftime('%Y-%m-%d')
    return df

def fetch_data(asset_key, lookback_years=2):
    """
    Fetches historical data from yfinance. Fallback to mock data if offline or fails.
    """
    if asset_key not in ASSETS:
        raise ValueError(f"Unknown asset: {asset_key}")
        
    asset_info = ASSETS[asset_key]
    ticker_symbol = asset_info["ticker"]
    
    end_date = datetime.now()
    start_date = end_date - timedelta(days=lookback_years * 365)
    
    start_str = start_date.strftime("%Y-%m-%d")
    end_str = end_date.strftime("%Y-%m-%d")
    
    df = None
    fetched_from_web = False
    
    try:
        # Try fetching real data via yfinance
        print(f"Attempting to fetch {asset_key} ({ticker_symbol}) from Yahoo Finance...")
        ticker = yf.Ticker(ticker_symbol)
        df_fetched = ticker.history(start=start_str, end=end_str, timeout=3.0)
        
        if not df_fetched.empty and len(df_fetched) > 10:
            df = df_fetched.reset_index()
            # Standardize columns
            df['Date'] = df['Date'].dt.strftime('%Y-%m-%d')
            df = df[['Date', 'Open', 'High', 'Low', 'Close', 'Volume']]
            fetched_from_web = True
            print(f"Successfully fetched {len(df)} records from Yahoo Finance.")
        else:
            print("yfinance returned empty or insufficient data. Falling back to mock generator.")
    except Exception as e:
        print(f"yfinance fetch failed due to: {e}. Falling back to mock generator.")
        
    if df is None:
        df = generate_mock_data(asset_key, start_str, end_str)
        print(f"Generated {len(df)} simulated records for {asset_key}.")
        
    # Calculate Technical Indicators
    df = add_technical_indicators(df)
    
    return df, fetched_from_web

def add_technical_indicators(df):
    """
    Computes technical indicators: SMA, EMA, RSI, and MACD.
    Assumes df has 'Close' column.
    """
    # Create a copy to avoid SettingWithCopy warnings
    df = df.copy()
    
    # 1. Simple Moving Averages (SMA)
    df['SMA_20'] = df['Close'].rolling(window=20).mean()
    df['SMA_50'] = df['Close'].rolling(window=50).mean()
    
    # 2. Exponential Moving Averages (EMA)
    df['EMA_12'] = df['Close'].ewm(span=12, adjust=False).mean()
    df['EMA_26'] = df['Close'].ewm(span=26, adjust=False).mean()
    
    # 3. Relative Strength Index (RSI)
    delta = df['Close'].diff()
    gain = delta.clip(lower=0)
    loss = -delta.clip(upper=0)
    
    # Wilder's smoothing technique for RSI
    avg_gain = gain.rolling(window=14).mean()
    avg_loss = loss.rolling(window=14).mean()
    
    # First values
    rs = avg_gain / (avg_loss + 1e-10) # Prevent division by zero
    df['RSI'] = 100 - (100 / (1 + rs))
    
    # Fill early NaN RSI values with 50 (neutral)
    df['RSI'] = df['RSI'].fillna(50)
    
    # 4. Moving Average Convergence Divergence (MACD)
    df['MACD'] = df['EMA_12'] - df['EMA_26']
    df['MACD_Signal'] = df['MACD'].ewm(span=9, adjust=False).mean()
    df['MACD_Hist'] = df['MACD'] - df['MACD_Signal']
    
    # Fill rest of NaNs (due to SMA window sizes) with forward fill, then backward fill
    df = df.ffill().bfill()
    
    return df

def get_asset_summary(df, asset_key):
    """
    Extracts summary stats (current price, high, low, change, sentiment signal)
    """
    asset_info = ASSETS[asset_key]
    
    if df.empty:
        return {}
        
    latest = df.iloc[-1]
    prev = df.iloc[-2] if len(df) > 1 else latest
    
    current_price = float(latest['Close'])
    prev_price = float(prev['Close'])
    price_change = current_price - prev_price
    pct_change = (price_change / prev_price) * 100
    
    # Determine summary signal based on RSI and moving averages
    rsi_val = float(latest['RSI'])
    sma20 = float(latest['SMA_20'])
    sma50 = float(latest['SMA_50'])
    
    signals = []
    if rsi_val > 70:
        signals.append("Overbought")
    elif rsi_val < 30:
        signals.append("Oversold")
        
    if current_price > sma20:
        signals.append("Bullish (Above SMA20)")
    else:
        signals.append("Bearish (Below SMA20)")
        
    if sma20 > sma50:
        signals.append("Golden Cross Trend")
    else:
        signals.append("Death Cross Trend")
        
    # Overall summary signal recommendation
    if rsi_val > 65 and current_price > sma20:
        signal = "BUY / BULLISH"
        signal_color = "success"
    elif rsi_val < 35 and current_price < sma20:
        signal = "SELL / BEARISH"
        signal_color = "danger"
    else:
        signal = "NEUTRAL / HOLD"
        signal_color = "warning"
        
    return {
        "ticker": asset_info["ticker"],
        "name": asset_info["name"],
        "unit": asset_info["unit"],
        "current_price": current_price,
        "price_change": price_change,
        "pct_change": pct_change,
        "high_24h": float(df.iloc[-20:]['High'].max()), # Proxy for 24h high (last 20 sessions)
        "low_24h": float(df.iloc[-20:]['Low'].min()),   # Proxy for 24h low
        "rsi": rsi_val,
        "macd": float(latest['MACD']),
        "macd_signal": float(latest['MACD_Signal']),
        "overall_signal": signal,
        "signal_color": signal_color,
        "signals_list": signals
    }

if __name__ == "__main__":
    # Test fetcher
    df, fetched = fetch_data("gold")
    print(df.head())
    print("Fetched from web?", fetched)
    print(get_asset_summary(df, "gold"))
