from flask import Flask, jsonify, request
from flask_cors import CORS
import random
from datetime import datetime, timedelta
import numpy as np

from data_fetcher import fetch_data, get_asset_summary, ASSETS
from model import train_and_predict

app = Flask(__name__)
CORS(app)  # Enable Cross-Origin Resource Sharing

# Mock News Template Generator to simulate a premium news sentiment analyzer
NEWS_TEMPLATES = {
    "gold": [
        {"title": "Federal Reserve Signals Rate Cuts Amid Cooling Inflation", "sentiment": "Bullish", "impact": "+1.4%"},
        {"title": "Geopolitical Tensions Drive Safe-Haven Demand for Precious Metals", "sentiment": "Bullish", "impact": "+2.1%"},
        {"title": "Global Central Banks Continue Gold Purchasing Spree in Q2", "sentiment": "Bullish", "impact": "+0.9%"},
        {"title": "US Dollar Strengthens, Pressuring Commodity Prices Downward", "sentiment": "Bearish", "impact": "-1.2%"},
        {"title": "Treasury Yields Rise to Multi-Month Highs, Reducing Gold Appeal", "sentiment": "Bearish", "impact": "-0.8%"},
        {"title": "Gold Retests Historic Resistence Levels Amid Liquidity Squeeze", "sentiment": "Neutral", "impact": "+0.1%"}
    ],
    "silver": [
        {"title": "Industrial Demand for Silver Soars in Solar Panel Production", "sentiment": "Bullish", "impact": "+2.5%"},
        {"title": "Silver Follows Gold Rally, Outperforming in Gold-Silver Ratio", "sentiment": "Bullish", "impact": "+3.0%"},
        {"title": "Mining Output Slowdowns in Peru Threaten Silver Supplies", "sentiment": "Bullish", "impact": "+1.8%"},
        {"title": "Industrial Activity Slowdown in China Damps Silver Prices", "sentiment": "Bearish", "impact": "-2.2%"},
        {"title": "Retail Silver ETFs Witness Massive Capital Outflows", "sentiment": "Bearish", "impact": "-1.5%"},
        {"title": "Silver Prices Consolidate Near Crucial Moving Averages", "sentiment": "Neutral", "impact": "-0.2%"}
    ],
    "nifty": [
        {"title": "Domestic Institutional Investors (DII) Fuel Mid-Cap Bull Run", "sentiment": "Bullish", "impact": "+1.1%"},
        {"title": "Excellent Q4 Earnings from Tech and Banking Giants Uplift Market", "sentiment": "Bullish", "impact": "+1.5%"},
        {"title": "Monsoon Progress inline with Expectations, Raising Agribusiness Outlook", "sentiment": "Bullish", "impact": "+0.7%"},
        {"title": "FII Capital Outflows Rise as US Treasury Yields Attract Global Funds", "sentiment": "Bearish", "impact": "-1.3%"},
        {"title": "Inflation Concerns Re-emerge as Oil Prices Spike Globally", "sentiment": "Bearish", "impact": "-0.9%"},
        {"title": "Nifty Index Trading in a Tight Range Ahead of RBI Policy Meeting", "sentiment": "Neutral", "impact": "0.0%"}
    ],
    "sensex": [
        {"title": "BSE Market Capitalization Crosses Landmark Milestone", "sentiment": "Bullish", "impact": "+1.2%"},
        {"title": "Foreign Direct Investment Inflows Reach Record High this Quarter", "sentiment": "Bullish", "impact": "+0.8%"},
        {"title": "Blue-Chip Stocks Lead Sensex Surge Over Key Resistance Levels", "sentiment": "Bullish", "impact": "+1.4%"},
        {"title": "Profit Booking Seen in Overvalued Small-Cap Segments", "sentiment": "Bearish", "impact": "-1.1%"},
        {"title": "Sensex Drifts Lower as Rupee Slides Against Strong US Dollar", "sentiment": "Bearish", "impact": "-0.7%"},
        {"title": "Consolidation Phase Expected for Major Sensex Indices this Week", "sentiment": "Neutral", "impact": "+0.2%"}
    ],
    "usd_inr": [
        {"title": "RBI Intervenes in Forex Market to Defend Rupee from Record Lows", "sentiment": "Bullish", "impact": "-0.4% (Rupee Strengthens)"},
        {"title": "FII Debt Inflows Rise, Boosting Rupee Liquidity", "sentiment": "Bullish", "impact": "-0.6% (Rupee Strengthens)"},
        {"title": "Crude Oil Price Drop Eases India's Import Bill, Bolsters Rupee", "sentiment": "Bullish", "impact": "-0.3% (Rupee Strengthens)"},
        {"title": "Hawkish Fed Commentary Powers US Dollar Index (DXY) Higher", "sentiment": "Bearish", "impact": "+0.8% (Rupee Depreciates)"},
        {"title": "India Trade Deficit Widens as Gold Imports Surge", "sentiment": "Bearish", "impact": "+0.5% (Rupee Depreciates)"},
        {"title": "USD/INR Holds Steady as Traders Await Inflation Print", "sentiment": "Neutral", "impact": "+0.0%"}
    ]
}

@app.route('/api/stocks', methods=['GET'])
def get_stocks():
    """
    Returns the supported assets and their configurations.
    """
    stock_list = []
    for key, info in ASSETS.items():
        stock_list.append({
            "key": key,
            "ticker": info["ticker"],
            "name": info["name"],
            "unit": info["unit"]
        })
    return jsonify(stock_list)

@app.route('/api/predict', methods=['GET'])
def get_prediction():
    """
    Triggers fetching, indicator calculation, training, and forecasting.
    Query params:
      - asset: (gold|silver|nifty|sensex|usd_inr)
      - model: (linear|random_forest)
      - lookback: number of historical training days (default: 365)
      - forecast: prediction forecast window (default: 7)
    """
    asset = request.args.get('asset', 'nifty').lower()
    model_type = request.args.get('model', 'linear').lower()
    
    try:
        lookback = int(request.args.get('lookback', 365))
        forecast = int(request.args.get('forecast', 7))
    except ValueError:
        return jsonify({"error": "Lookback and forecast windows must be integers"}), 400
        
    if asset not in ASSETS:
        return jsonify({"error": f"Unsupported asset: '{asset}'. Must be one of {list(ASSETS.keys())}"}), 400
        
    if model_type not in ['linear', 'random_forest']:
        return jsonify({"error": f"Unsupported model type: '{model_type}'"}), 400
        
    # Cap inputs to protect server performance
    lookback = min(max(lookback, 60), 730)
    forecast = min(max(forecast, 1), 30)
    
    try:
        # Fetch historical data (includes indicators)
        df, fetched_from_web = fetch_data(asset, lookback_years=2)
        
        # Calculate summary statistics
        summary = get_asset_summary(df, asset)
        summary["fetched_from_web"] = fetched_from_web
        
        # Run ML model (it will train on lookback subset and predict future)
        predictions_data = train_and_predict(
            df=df,
            model_type=model_type,
            forecast_days=forecast,
            lookback_days=lookback
        )
        
        # Calculate next day forecast metrics
        next_day_date = predictions_data["dates"][0]
        next_day_pred = predictions_data["predictions"][0]
        current_price = float(df.iloc[-1]["Close"])
        expected_change = next_day_pred - current_price
        expected_pct_change = (expected_change / current_price) * 100
        direction = "UP" if expected_change >= 0 else "DOWN"
        
        rmse = predictions_data["metrics"]["rmse"]
        conf_low = max(0.01, next_day_pred - rmse)
        conf_high = next_day_pred + rmse
        
        next_day_forecast = {
            "date": next_day_date,
            "predicted_price": next_day_pred,
            "expected_change": expected_change,
            "expected_pct_change": expected_pct_change,
            "direction": direction,
            "confidence_low": conf_low,
            "confidence_high": conf_high
        }
        
        # Format history data to return to UI
        # Only return the required history size (plus enough for indicators) to reduce payload size
        history_subset = df.iloc[-(lookback + 50):] if len(df) > (lookback + 50) else df
        
        history_records = []
        for _, row in history_subset.iterrows():
            history_records.append({
                "Date": row["Date"],
                "Open": float(row["Open"]),
                "High": float(row["High"]),
                "Low": float(row["Low"]),
                "Close": float(row["Close"]),
                "Volume": float(row["Volume"]),
                "SMA_20": float(row["SMA_20"]) if not np.isnan(row["SMA_20"]) else None,
                "SMA_50": float(row["SMA_50"]) if not np.isnan(row["SMA_50"]) else None,
                "RSI": float(row["RSI"]) if not np.isnan(row["RSI"]) else 50.0,
                "MACD": float(row["MACD"]) if not np.isnan(row["MACD"]) else 0.0,
                "MACD_Signal": float(row["MACD_Signal"]) if not np.isnan(row["MACD_Signal"]) else 0.0,
                "MACD_Hist": float(row["MACD_Hist"]) if not np.isnan(row["MACD_Hist"]) else 0.0,
            })
            
        return jsonify({
            "asset": asset,
            "model": model_type,
            "lookback": lookback,
            "forecast": forecast,
            "summary": summary,
            "history": history_records,
            "prediction": predictions_data,
            "next_day_forecast": next_day_forecast
        })
        
    except Exception as e:
        import traceback
        traceback.print_exc()
        return jsonify({"error": f"Internal server error: {str(e)}"}), 500

@app.route('/api/news', methods=['GET'])
def get_news():
    """
    Returns simulated dynamic news items tailored to the requested asset
    along with randomized time stamps for live dashboard realism.
    """
    asset = request.args.get('asset', 'nifty').lower()
    if asset not in ASSETS:
        return jsonify({"error": f"Unsupported asset: '{asset}'"}), 400
        
    templates = NEWS_TEMPLATES[asset]
    
    # Shuffle and generate 3-5 randomized news articles
    chosen = random.sample(templates, k=min(4, len(templates)))
    
    news_items = []
    now = datetime.now()
    
    for i, item in enumerate(chosen):
        # Stagger publication hours in the past
        hours_ago = (i * 3) + random.randint(1, 2)
        pub_time = now - timedelta(hours=hours_ago)
        
        # Generate random news source
        source = random.choice(["Financial Times", "Bloomberg", "Reuters", "MarketWatch", "CNBC"])
        
        news_items.append({
            "title": item["title"],
            "sentiment": item["sentiment"],
            "impact": item["impact"],
            "source": source,
            "time": pub_time.strftime("%I:%M %p (%d %b)")
        })
        
    # Calculate aggregate sentiment score based on headlines
    sentiment_values = {"Bullish": 1.0, "Bearish": -1.0, "Neutral": 0.0}
    avg_score = sum(sentiment_values[item["sentiment"]] for item in chosen) / len(chosen)
    # Convert score from range [-1, 1] to a percentage [0, 100]% (where 50% is neutral)
    sentiment_percentage = int((avg_score + 1) * 50)
    
    sentiment_label = "Neutral"
    if sentiment_percentage > 60:
        sentiment_label = "Strong Bullish" if sentiment_percentage > 75 else "Bullish"
    elif sentiment_percentage < 40:
        sentiment_label = "Strong Bearish" if sentiment_percentage < 25 else "Bearish"
        
    return jsonify({
        "asset": asset,
        "sentiment_score": sentiment_percentage,
        "sentiment_label": sentiment_label,
        "news": news_items
    })

if __name__ == '__main__':
    # Running on port 5050 to avoid local port conflicts
    app.run(host='127.0.0.1', port=5050, debug=True)
